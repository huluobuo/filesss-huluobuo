# huluobuo.github.io


# 中文_简体
## 个人介绍
- 姓名：！！！机密！！！（额）
- 性别：男
- 年龄：12
- 学历：初一（在校）
- 专业：(不用说了吧)
- 毕业院校：（在校）
- 联系方式：Email
- 邮箱：HelloHuHi@outlook.com/hu_luo_buo@outlook.com

## 技能
- 写一点点代码
- 做一点点小小小小小...项目
- 玩亿点点游戏

## 空余时间
- 法定节假日（如春节等）
- 周五晚上、周六、周日（偶尔）
- 以上不一定999999999%准确
- 因为我还是学生



# English
## Personal Introduction
- Name: !!!Secret!!! (Um)
- Gender: Male
- Age: 12
- Education: Junior High School (Currently Enrolled)
- Major: (You can guess)
- Graduated Institution: (Currently Enrolled)
- Contact Method: Email
- Email: HelloHuHi@outlook.com/hu_luo_buo@outlook.com

## Skills
- Write a little bit of code
- Do a little bit of small projects
- Play a lot of games

## Spare Time
- Legal holidays (such as Spring Festival, etc.)
- Friday night, Saturday, Sunday (occasionally)
- The above is not necessarily 999999999% accurate
- Because I am still a student
